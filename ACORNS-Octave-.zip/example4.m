% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 4                                                                %
%                                                                             %
%                                                                             %
% This is Example 1 in Fortun and Mendoza (2020): Power law approximation of  %
%    the pre-industrial carbon cycle model                                    %
%                                                                             %
% RESULT: The network has absolute concentration robustness in 1 species:     %
%            A2.                                                              %
%                                                                             %
% Reference: Fortun N, Mendoza E (2020) Absolute concentration robustness in  %
%    power law kinetic systems. MATCH Commun Math Comput Chem 85(3):669-691.  %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model.species = { }; % do not fill out; will be filled automatically by 'acr' or 'acr2'
model.reaction(1) = struct('id', 'A1+2A2<->2A1+A2', 'reactant', struct('species', {'A1', 'A2'}, 'stoichiometry', {1, 2}), 'product', struct('species', {'A1', 'A2'}, 'stoichiometry', {2, 1}), 'reversible', true, 'kinetic', struct('reactant1', [-68, 0.58], 'reactant2', [-68, 0.91]));
model.reaction(2) = struct('id', 'A2<->A3', 'reactant', struct('species', {'A2'}, 'stoichiometry', {1}), 'product', struct('species', {'A3'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);