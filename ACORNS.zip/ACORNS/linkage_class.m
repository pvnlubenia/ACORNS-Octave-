# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    linkage_class                                                            #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a vector whose entries are the linkage class numbers where  #
#            each vertex (representing a complex) of an undirected graph      #
#            belongs to. The function returns an empty value if there are no  #
#            vertices in the graph.                                           #
# INPUT: g: a structure with fields 'vertices' and 'edges'                    #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 19 July 2021                                                       #
# Last Modified: 29 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function link_class = linkage_class(g)
    
    % Initialize the vector which will indicate which linkage class number a vertex (i.e., complex) belongs to
    link_class = zeros(numel(g.vertices), 1);
    
    % Initialize the linkage class number tracker
    link_class_num = 0;
    
    % Go to each vertex
    for i = 1:numel(g.vertices)
        
        % Pay attention only to a vertex which has no linkage class number yet
        if link_class(i) == 0
            
            % This vertex goes to the next linkage class number
            link_class_num += 1;
            
            % Assign the linkage class number to the vertex
            link_class(i) = link_class_num;
            
            % Take note of the vertex that needs to be checked for edges
            to_check = [i];
            
            % Continue assigning a linkage class number to vertices that get into the check list
            while ~isempty(to_check)
                
                % Get the vertex in the check list
                v1 = to_check(end);
                
                % Remove the vertex from the check list (since we now know which vertex to focus on)
                to_check(end) = [ ];
                
                % Check to which vertices the vertex is connected to
                for j = 1:numel(g.edges{v1})
                    
                    % Take note of the vertex it is connected to
                    v2 = g.edges{v1}(j).vertex;
                    
                    % Pay attention to this vertex if it has no linkage class number yet
                    if link_class(v2) == 0
                        
                        % Assign this vertex with the same linkage class number as the vertex it is connected to
                        link_class(v2) = link_class_num;
                        
                        % Add this vertex to our check list: in the next round, we'll check to which other vertices it is connected to
                        to_check(end+1) = v2;
                    end
                end
            end
        end
    end