# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    add_edge                                                                 #
#                                                                             #
#                                                                             #
# OUTPUT: Adds an undirected edge between two vertices. The vertex connected  #
#            to a vertex is indicated in the subfield 'vertex' and the label  #
#            for the edge is in the subfield 'label'. Both subfields are      #
#            under the field 'edges' corresponding to the vertex. The field   #
#            and subfields belong to the structure representing the graph.    #
# INPUTS:                                                                     #
#         - g: a structure with fields 'vertices' and 'edges'                 #
#         - v1, v2: strings representing the vertices connected by an         #
#              undirected edge (make sure add_vertex has been used to add the #
#              vertices v1 and v2 to g)                                       #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 18 July 2021                                                       #
# Last Modified: 30 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function g = add_edge(g, v1, v2)
    
    %
    % STEP 1: Make sure vertices v1 and v2 are already in undirected graph g
    %
    
    % Case 1: v1 or v2 is not in g
    if (isempty(find(strcmp(v1, g.vertices))) || isempty(find(strcmp(v2, g.vertices))))
        disp(['Make sure both ' v1 ' and ' v2 ' are in the graph.']);
        
    % Case 2: Both vertices are already in g
    else
        
        % Case 2.1: The vertices are the same
        if strcmp(v1, v2) == 1
            disp(['Make sure the vertices are different.']);
            
            
            
    %
    % STEP 2: Record the edge connecting v1 and v2
    %
    
        % Case 2.2: The vertices are different
        else
            
            % Get the index of v1 and v2 in g.vertices
            v1_index = find(strcmp(v1, g.vertices));
            v2_index = find(strcmp(v2, g.vertices));
            
            % Check if an edge with v1 already exists
            try
                g.edges{v1_index};
            catch
                
                % If none, initialize g.edges for v1
                g.edges{v1_index} = cell();
            end
            
            % Check if an edge with v2 already exists
            try
                g.edges{v2_index};
            catch
                
                % If none, initialize g.edges for v2
                g.edges{v2_index} = cell();
            end
            
            % After all the controls above have been implemented, add an edge in the 'edges' field in g for both v1 and v2
            g.edges{v1_index}(end+1) = struct('vertex', v2_index, 'label', [v1 '-' v2]);
            g.edges{v2_index}(end+1) = struct('vertex', v1_index, 'label', [v2 '-' v1]);
        end
    end