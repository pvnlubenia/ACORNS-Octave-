# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    is_weakly_reversible                                                     #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a value of 1 if the network is weakly reversible, 0         #
#            otherwise.                                                       #
# INPUT: model: a structure, representing the CRN, with the following fields  #
#           (the kinetics of the network is not needed):                      #
#           - id: name of the model                                           #
#              - species: a list of all species in the network; THIS IS       #
#                   ASSUMED TO HAVE BEEN FILLED OUT ALREADY BY ANOTHER        #
#                   FUNCTION                                                  #
#           - reaction: a list of all reactions in the network, each with the #
#                following subfields:                                         #
#                   - id: a string representing the reaction                  #
#                   - reactant: has the following further subfields:          #
#                        - species: a list of strings representing the        #
#                             species in the reactant complex                 #
#                        - stoichiometry: a list of numbers representing the  #
#                             stoichiometric coefficient of each species in   #
#                             the reactant complex (listed in the same order  #
#                             of the species)                                 #
#                   - product: has the following further subfields:           #
#                        - species: a list of strings representing the        #
#                             species in the product complex                  #
#                        - stoichiometry: a list of numbers representing the  #
#                             stoichiometric coefficient of each species in   #
#                             the product complex (listed in the same order   #
#                             of the species)                                 #
#                   - reversible: has the value true or false indicating if   #
#                        the reaction is reversible or not, respectively      #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 29 October 2021                                                    #
# Last Modified: 30 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function weakly_reversible = is_weakly_reversible(model)
    
    %
    % STEP 1: Form stoichiometric matrix N
    %
    
    % Count the number of species
    m = numel(model.species);
    
    % Initialize the matrix of reactant complexes
    reactant_complex = [ ];
    
    % Initialize the matrix of product complexes
    product_complex = [ ];
    
    % Initialize the stoichiometric matrix
    N = [ ];
    
    % For each reaction in the model
    for i = 1:numel(model.reaction)
        
        % Initialize the vector for the reaction's reactant complex
        reactant_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the reactant complex
        for j = 1:numel(model.reaction(i).reactant)
            reactant_complex(find(strcmp(model.reaction(i).reactant(j).species, model.species), 1), end) = model.reaction(i).reactant(j).stoichiometry;
        end
        
        % Initialize the vector for the reaction's product complex
        product_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the product complex
        for j = 1:numel(model.reaction(i).product)
            product_complex(find(strcmp(model.reaction(i).product(j).species, model.species), 1), end) = model.reaction(i).product(j).stoichiometry;
        end
        
        % Create a vector for the stoichiometric matrix: Difference between the two previous vectors
        N(:, end+1) = product_complex(:, end) - reactant_complex(:, end);
        
        % If the reaction is reversible
        if model.reaction(i).reversible
            
            % Insert a new vector for the reactant complex: make it same as the product complex
            reactant_complex(:, end+1) = product_complex(:, end);
            
            % Insert a new vector for the product complex: make it the same as the reactant complex
            product_complex(:, end+1) = reactant_complex(:, end-1);
            
            % Insert a new vector in the stoichiometric matrix: make it the additive inverse of the vector formed earlier
            N(:, end+1) = -N(:, end);
        end
    end
    
    % Count the total number of reactions
    r = size(N, 2);
    
    
    
    %
    % STEP 2: Determine the number of [unique] complexes
    %
    
    % Get just the unique complexes
    % ind2(i) is the index in Y of the reactant complex in reaction i
    % ind(i+r) is the index in Y of the product complex in reaction i     
    [Y, ind, ind2] = unique([reactant_complex, product_complex]', 'rows');
    
    % Construct the matrix of complexes
    Y = Y';
    
    % Count the number of complexes
    n = size(Y, 2);
    
    
    
    %
    % STEP 3: Create an undirected graph
    %
    
    % Initialize an undirected graph g
    g = init_graph();

    % Go through each column of Y (a complex)
    for i = 1:n
        
        % For the zero complex
        if numel(find(Y(:, i))) == 0
            complex = '0';
        
        % Otherwise
        else
            
            % Check which species appear in the complex
            for j = 1:numel(find(Y(:, i)))
                
                % For the first species
                if j == 1
                    
                    % Don't show the stoichiometry if it's 1
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [model.species{find(Y(:, i))(j)}];
                    
                    % Otherwise, include it
                    else
                        complex = [num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                
                % We need the + sign for succeeding species
                else
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [complex, '+', model.species{find(Y(:, i))(j)}];
                    else
                        complex = [complex, '+', num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                end
            end 
        end
        
        % Add this complex in the list of vertices of g
        g = add_vertex(g, complex);
    end
    
    % Add edges to g: Ci -> Cj forms an edge
    % ~ suppresses the original output
    for i = 1:r
        g = add_edge(g, g.vertices{[~, loc] = ismember(reactant_complex(:, i)', Y', 'rows')}, g.vertices{[~, loc] = ismember(product_complex(:, i)', Y', 'rows')});
    end
    
    
    
    %
    % STEP 4: Determine the number of linkage classes
    %
    
    % Initialize the vector which will indicate in which linkage class number a vertex (i.e., complex) belongs to
    linkage_class = zeros(numel(g.vertices), 1);
    
    % Initialize the linkage class number tracker
    linkage_class_num = 0;
    
    % Go to each vertex
    for i = 1:numel(g.vertices)
        
        % Pay attention only to a vertex which has no linkage class number yet
        if linkage_class(i) == 0
            
            % This vertex goes to the next linkage class number
            linkage_class_num += 1;
            
            % Assign the linkage class number to the vertex
            linkage_class(i) = linkage_class_num;
            
            % Take note of the vertex that needs to be checked for edges
            to_check = [i];
            
            % Continue assigning a linkage class number to vertices that get into the check list
            while ~isempty(to_check)
                
                % Get the vertex in the check list
                v1 = to_check(end);
                
                % Remove the vertex from the check list (since we now know which vertex to focus on)
                to_check(end) = [ ];
                
                % Check to which vertices the vertex is connected to
                for j = 1:numel(g.edges{v1})
                    
                    % Take note of the vertex it is connected to
                    v2 = g.edges{v1}(j).vertex;
                    
                    % Pay attention to this vertex if it has no linkage class number yet
                    if linkage_class(v2) == 0
                        
                        % Assign this vertex with the same linkage class number as the vertex it is connected to
                        linkage_class(v2) = linkage_class_num;
                        
                        % Add this vertex to our check list: in the next round, we'll check to which other vertices it is connected to
                        to_check(end+1) = v2;
                    end
                end
            end
        end
    end
    
    % Count the number of linkage classes
    l = max(linkage_class);
    
    
    
    %
    % STEP 5: Create a directed graph
    %
    
    % Initialize a directed graph g
    g = init_graph();

    % Go through each column of Y (a complex)
    for i = 1:n
        
        % For the zero complex
        if numel(find(Y(:, i))) == 0
            complex = '0';
        
        % Otherwise
        else
            
            % Check which species appear in the complex
            for j = 1:numel(find(Y(:, i)))
                
                % For the first species
                if j == 1
                    
                    % Don't show the stoichiometry if it's 1
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [model.species{find(Y(:, i))(j)}];
                    
                    % Otherwise, include it
                    else
                        complex = [num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                
                % We need the + sign for succeeding species
                else
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [complex, '+', model.species{find(Y(:, i))(j)}];
                    else
                        complex = [complex, '+', num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                end
            end 
        end
        
        % Add this complex in the list of vertices of G
        g = add_vertex(g, complex);
    end
    
    % Add a directed edge to g: Ci -> Cj forms an edge
    for i = 1:r
        g = add_path(g, g.vertices{[~, loc] = ismember(reactant_complex(:, i)', Y', 'rows')}, g.vertices{[~, loc] = ismember(product_complex(:, i)', Y', 'rows')});
    end
    
    
    
    %
    % STEP 6: Determine the number of strong linkage classes
    %
    
    % Define function which visits each complex (i.e., vertex) v and the other vertices connected to it
    function visit(v)
        
        % Set the discovery time of the complex as the current time
        discovery_time(v) = time;
        
        % Set the discovery time of the strong linkage class as the current time
        slc_discovery_time(v) = time;
        
        % Move the time forward for the next complex
        time = time + 1;
        
        % Add the complex in the list of complexes in the same strong linkage class
        stack(end+1) = v;
        
        % Note that the complex is already listed in the strong linkage class
        on_stack(v) = true;
        
        % Go through each edge connected to the vertex (i.e., complex)
        for j = 1:numel(g.edges{v})
            
            % Take the vertex connected to it
            v2 = g.edges{v}(j).vertex;
            
            % If the vertex is not yet visited
            if discovery_time(v2) == 0
                
                % Apply the visit function to this vertex
                visit(v2);
                
                % Set the discovery time of the strong linkage class
                % slc_discovery_time(v2) < slc_discovery_time(v) iff a vertex in the stack before v is reachable from v2 (and so they are all in the same strong linkage class)
                slc_discovery_time(v) = min(slc_discovery_time(v), slc_discovery_time(v2));
            
            % If v2 was visited before v
            elseif on_stack(v2)
                
                % So v and v2 are in the same component, and they must have the same slc_discovery_time
                slc_discovery_time(v) = min(slc_discovery_time(v), slc_discovery_time(v2));
            end
        end
        
        % If v is the first visited node of its strong linkage class, all the other vertices of the strong linkage class follow it on the stack
        if slc_discovery_time(v) == discovery_time(v) 
            while true
                v2 = stack(end);
                stack(end) = [];
                on_stack(v2) = false;
                strong_linkage_class(v2) = slc_num;
                if v2 == v
                    break
                end
            end
            
            % Add 1 to the strong linkage class number
            slc_num = slc_num + 1;
        end
    end
    
    % This is the actual function
    
    % Initialize the discovery time of the vertices
    discovery_time = zeros(numel(g.vertices), 1);
    
    % Initialize the discovery time of the [first visited complex of the] strong linkage class of the vertices
    slc_discovery_time = zeros(numel(g.vertices), 1);
    
    % Start the timer at 1
    time = 1;
    
    % Initialize the list of complexes in the strong linkage class
    stack = [ ];
    
    % Initialize that no vertex is on a strong linkage class
    on_stack = false(numel(g.vertices), 1);
    
    % Initialize vector of strong linkage class numbers
    strong_linkage_class = zeros(numel(g.vertices), 1);
    
    % Start numbering the strong linkage class at 1
    slc_num = 1;
    
    % Go through each complex (i.e., vertex)
    for i = 1:numel(g.vertices)
        
        % Use the visit function if it has no strong linkage classs number
        if strong_linkage_class(i) == 0
            visit(i);
        end
    end
    
    % Count the number of strong linkage classes
    sl = max(strong_linkage_class);
    
    
    
    %
    % STEP 7: Determine if the network is weakly reversible
    %
    
    % Weakly reversible if the number of linkage classes and the number of strong linkage classes are the same
    if sl == l
        weakly_reversible = 1;
    else
        weakly_reversible = 0;
    end
end