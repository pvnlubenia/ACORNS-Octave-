# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    R_in_span_union                                                          #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a value of 1 for the variable 'binary_decomp' if R is in    #
#            the union of span(B1) and span(B2), i.e., an independent binary  #
#            decomposition of R is formed.                                    #
#         The output variables 'span_B1' and 'span_B2' allows the user to     #
#            view the elements (reaction numbers) in span(B1) and span(B2),   #
#            respectively.                                                    #
# INPUTS:                                                                     #
#         - B1: an array of the reaction numbers of a Shinar-Feinberg pair    #
#         - B2: an array of the reaction numbers of the vectors added to      #
#              extend B1 to a basis for R                                     #
#         - R: a matrix of reaction vectors of a chemical reaction network    #
#                                                                             #
# Created: 24 July 2021                                                       #
# Last Modified: 5 August 2021                                                #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function [binary_decomp, span_B1, span_B2] = R_in_span_union(B1, B2, R)
    
    %
    % Form span(B1) and span(B2)
    %
    
    % Get the reaction vectors forming B1 and forming B2
    set_B1 = R(B1, :);
    set_B2 = R(B2, :);
    
    % Initialize list of reactions in span(B1) and in span(B2)
    span_B1 = [ ];
    span_B2 = [ ];
    
    % Go through each reaction vector
    for i = 1:size(R, 1)
        
        % If the reaction vector is a linear combination of 'set_B1'
        if rank([set_B1', R(i, :)']) == rank(set_B1')
            
            % Add this reaction vector number to 'span_B1'
            span_B1(end+1) = i;
        end
        
        % If the reaction vector is a linear combination of 'set_B2'
        if rank([set_B2', R(i, :)']) == rank(set_B2')
            
            % Add this reaction vector number to 'span_B2'
            span_B2(end+1) = i;
        end
    end
    
    
    
    %
    % Get the union of span(B1) and span(B2)
    %
    
    span_B1_U_span_B2 = union(span_B1, span_B2);
    
    % If the union becomes a vertical vector: This happens in Octave when one of the sets being combined is empty
    if size(span_B1_U_span_B2, 1) > 1
        
        % Transpose
        span_B1_U_span_B2 = span_B1_U_span_B2';
    end
    
    
    
    %
    % Check if 'span_B1_U_span_B2' contains all reactions
    %
    
    % If R is in the union of span(B1) and span(B2), an independent binary decomposition is formed
    if isequal(1:size(R, 1), span_B1_U_span_B2)
        binary_decomp = 1;
    else
        binary_decomp = 0;
    end