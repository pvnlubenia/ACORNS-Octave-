# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    strong_linkage_class                                                     #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a vector whose entries are the strong linkage class numbers #
#            where each vertex (representing a complex) of a directed graph   #
#            belongs to. The function returns an empty value if there are no  #
#            vertices in the graph.                                           #
# INPUT: g: a structure with fields 'vertices' and 'edges'                    #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 29 October 2021                                                    #
# Last Modified: 29 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function strong_link_class = strong_linkage_class(g)

    % Define function which visits each complex (i.e., vertex) v and the other vertices connected to it
    function visit(v)
        
        % Set the discovery time of the complex as the current time
        discovery_time(v) = time;
        
        % Set the discovery time of the strong linkage class as the current time
        slc_discovery_time(v) = time;
        
        % Move the time forward for the next complex
        time = time + 1;
        
        % Add the complex in the list of complexes in the same strong linkage class
        stack(end+1) = v;
        
        % Note that the complex is already listed in the strong linkage class
        on_stack(v) = true;
        
        % Go through each edge connected to the vertex (i.e., complex)
        for j = 1:numel(g.edges{v})
            
            % Take the vertex connected to it
            v2 = g.edges{v}(j).vertex;
            
            % If the vertex is not yet visited
            if discovery_time(v2) == 0
                
                % Apply the visit function to this vertex
                visit(v2);
                
                % Set the discovery time of the strong linkage class
                % slc_discovery_time(v2) < slc_discovery_time(v) iff a vertex in the stack before v is reachable from v2 (and so they are all in the same strong linkage class)
                slc_discovery_time(v) = min(slc_discovery_time(v), slc_discovery_time(v2));
            
            % If v2 was visited before v
            elseif on_stack(v2)
                
                % So v and v2 are in the same component, and they must have the same slc_discovery_time
                slc_discovery_time(v) = min(slc_discovery_time(v), slc_discovery_time(v2));
            end
        end
        
        % If v is the first visited node of its strong linkage class, all the other vertices of the strong linkage class follow it on the stack
        if slc_discovery_time(v) == discovery_time(v) 
            while true
                v2 = stack(end);
                stack(end) = [];
                on_stack(v2) = false;
                strong_link_class(v2) = n_slc;
                if v2 == v
                    break
                end
            end
            
            % Add 1 to the strong linkage class number
            n_slc = n_slc + 1;
        end
    end
    
    % This is the actual function
    
    % Initialize the discovery time of the vertices
    discovery_time = zeros(numel(g.vertices), 1);
    
    % Initialize the discovery time of the [first visited complex of the] strong linkage class of the vertices
    slc_discovery_time = zeros(numel(g.vertices), 1);
    
    % Start the timer at 1
    time = 1;
    
    % Initialize the list of complexes in the strong linkage class
    stack = [ ];
    
    % Initialize that no vertex is on a strong linkage class
    on_stack = false(numel(g.vertices), 1);
    
    % Initialize vector of strong linkage class numbers
    strong_link_class = zeros(numel(g.vertices), 1);
    
    % Start numbering the strong linkage class at 1
    n_slc = 1;
    
    % Go through each complex (i.e., vertex)
    for i = 1:numel(g.vertices)
        
        % Use the visit function if it has no strong linkage classs number
        if strong_link_class(i) == 0
            visit(i);
        end
    end
end