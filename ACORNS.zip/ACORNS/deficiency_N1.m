# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    deficiency_N1                                                            #
#                                                                             #
#                                                                             #
# OUTPUT: Creates a network out of a list of reactions from another network,  #
#            then returns the deficiency value of the newly-formed chemical   #
#            reaction network (CRN).                                          #
#         The output variables 'model_N1' and 'delta1' allow the user to view #
#            the following, respectively:                                     #
#               - New network formed                                          #
#               - Deficiency of the new network                               #
# INPUTS:                                                                     #
#         - model: a structure, representing the CRN, with the following      #
#              fields (the kinetics of the network is not needed):            #
#              - id: name of the model                                        #
#              - species: a list of all species in the network; this is left  #
#                   blank since incorporated into the function is a step      #
#                   which compiles all species used in the model              #
#              - reaction: a list of all reactions in the network, each with  #
#                   the following subfields:                                  #
#                      - id: a string representing the reaction               #
#                      - reactant: has the following further subfields:       #
#                           - species: a list of strings representing the     #
#                                species in the reactant complex              #
#                           - stoichiometry: a list of numbers representing   #
#                                the stoichiometric coefficient of each       #
#                                species in the reactant complex (listed in   #
#                                the same order of the species)               #
#                      - product: has the following further subfields:        #
#                           - species: a list of strings representing the     #
#                                species in the product complex               #
#                           - stoichiometry: a list of numbers representing   #
#                                the stoichiometric coefficient of each       #
#                                species in the product complex (listed in    #
#                                the same order of the species)               #
#                      - reversible: has the value true or false indicating   #
#                           if the reaction is reversible or not, resp.       #
#                      - kinetic: has the following further subfields:        #
#                           - reactant1: a list of numbers representing the   #
#                                kinetic order of each species in the         #
#                                reactant complex in the left to right        #
#                                direction (listed in the same order of the   #
#                                species)                                     #
#                           - reactant2: a list of numbers representing the   #
#                                kinetic order of each species in the         #
#                                reactant complex in the right to left        #
#                                direction (listed in the same order of the   #
#                                species)                                     #
#         - span_B1: list of reaction numbers of 'model' that will be used to #
#              form 'model_N1'                                                #
#                                                                             #
# Created: 25 July 2021                                                       #
# Last Modified: 28 July 2021                                                 #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function [model_N1, delta1] = deficiency_N1(model, span_B1)
    
    %
    % Create new model using the reaction numbers listed in 'span_B1'
    %
    
    % Preliminaries
    model_N1.id = 'span_B1';
    model_N1.species = { }; % do not fill out; will be filled automatically by 'deficiency'
    
    % Create a vector of model.reaction numbers for the total number of reactions
    reac_num = [ ];
    for i = 1:numel(model.reaction)
        if model.reaction(i).reversible == 0
            reac_num(end+1) = i;
        else
            reac_num(end+1) = i;
            reac_num(end+1) = i;
        end
    end
    
    % Get all model reaction numbers corresponding to the reactions in 'span_B1'
    reac = unique(reac_num(span_B1));
    
    % Put these reaction numbers in the new model
    for i = 1:numel(reac)
        model_N1.reaction(i) = model.reaction(reac(i));
    end
    
    
    
    %
    % Get the deficiency of the new model
    %
    
    % Use the function 'deficiency'
    [model_N1, delta1] = deficiency(model_N1);