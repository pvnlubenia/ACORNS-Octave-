# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    is_PL_RDK                                                                #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a value of 1 if the power law kinetic system has reactant-  #
#            determined kinetics (PL-RDK), 0 otherwise.                       #
# INPUT: model: a structure, representing the CRN, with the following fields: #
#           - id: name of the model                                           #
#           - species: a list of all species in the network; this is left     #
#                blank since incorporated into the function is a step which   #
#                compiles all species used in the model                       #
#           - reaction: a list of all reactions in the network, each with the #
#                following subfields:                                         #
#                   - id: a string representing the reaction                  #
#                   - reactant: has the following further subfields:          #
#                        - species: a list of strings representing the        #
#                             species in the reactant complex                 #
#                        - stoichiometry: a list of numbers representing the  #
#                             stoichiometric coefficient of each species in   #
#                             the reactant complex (listed in the same order  #
#                             of the species)                                 #
#                   - product: has the following further subfields:           #
#                        - species: a list of strings representing the        #
#                             species in the product complex                  #
#                        - stoichiometry: a list of numbers representing the  #
#                             stoichiometric coefficient of each species in   #
#                             the product complex (listed in the same order   #
#                             of the species)                                 #
#                   - reversible: has the value true or false indicating if   #
#                        the reaction is reversible or not, respectively      #
#                   - kinetic: has the following further subfields:           #
#                        - reactant1: a list of numbers representing the      #
#                             kinetic order of each species in the reactant   #
#                             complex in the left to right direction (listed  #
#                             in the same order of the species)               #
#                        - reactant2: a list of numbers representing the      #
#                             kinetic order of each species in the reactant   #
#                             complex in the right to left direction (listed  #
#                             in the same order of the species) (empty if the #
#                             reaction is not reversible)                     #
#        Note: It is assumed that the CRN has power law kinetics.             #
#                                                                             #
# References:                                                                 #
#   [1] Fontanil, L.L., Mendoza, E.R., and Fortun, N.T. (2021). A             #
#          computational approach to concentration robustness in power law    #
#          kinetic systems of Shinar-Feinberg type. MATCH Communications in   #
#          Mathematical and in Computer Chemistry, 86, 489-516.               #
#   [2] Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for chemical   #
#          chemical reaction network theory. Bioinformatics, 25(21),          #
#          2853–2854. doi:10.1093/bioinformatics/btp513.                      #
#                                                                             #
# Created: 26 July 2021                                                       #
# Last Modified: 29 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function is_RDK = is_PL_RDK(model)
    
    %
    % Add to 'model.species' all species indicated in the reactions
    %
    
    % Get all species from reactants
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).reactant)
            model.species{end+1} = model.reaction(i).reactant(j).species;
        end
    end
    
    % Get species from products
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).product)
            model.species{end+1} = model.reaction(i).product(j).species;
        end
    end
    
    % Get only unique species
    model.species = unique(model.species);
    
    % Count the number of species
    m = numel(model.species);
    
    
    
    %
    % Reactant Complexes
    %
    
    % Initialize the matrix of reactant complexes
    reactant_complexes = [ ];
    
    % Initialize the matrix of product complexes
    product_complexes = [ ];
    
    % For each reaction in the model
    for i = 1:numel(model.reaction)
        
        % Initialize the vector for the reaction's reactant complex
        reactant_complexes(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the reactant complex
        for j = 1:numel(model.reaction(i).reactant)
            reactant_complexes(find(strcmp(model.reaction(i).reactant(j).species, model.species), 1), end) = model.reaction(i).reactant(j).stoichiometry;
        end
        
        % Initialize the vector for the reaction's product complex
        product_complexes(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the product complex
        for j = 1:numel(model.reaction(i).product)
            product_complexes(find(strcmp(model.reaction(i).product(j).species, model.species), 1), end) = model.reaction(i).product(j).stoichiometry;
        end
        
        % If the reaction is reversible
        if model.reaction(i).reversible
            
            % Insert a new vector for the reactant complex: make it same as the product complex
            reactant_complexes(:, end+1) = product_complexes(:, end);
            
            % Insert a new vector for the product complex: make it the same as the reactant complex
            product_complexes(:, end+1) = reactant_complexes(:, end-1);
        end
    end
    
    % Form matrix of reactant complexes
    reactant_complexes = reactant_complexes';
    
    % Get the total number of reactions
    r = size(reactant_complexes, 1);
    
    % Get the unique reactant complexes
    [reactant_complexes_unique, reaction_number_unique, label] = unique(reactant_complexes, 'rows');
    
    % Count the number of unique reactant complexes
    n_r = size(reactant_complexes_unique, 1);
    
    
    
    %
    % Branching reactions
    %
    
    % Get the labels of non-unique reactant complexes
    same_label = find(hist(label, unique(label)) > 1);
    
    % Initialize list reactions numbers with similar reactants
    branching_complexes = { };
    
    % Group together reaction numbers with the same label
    for i = 1:numel(same_label)
        branching_complexes{i} = find((label == same_label(i)));
    end
    
    % Initialize list of branching reactions
    branching_reaction = [ ];
    
    % Create a list of pairwise branching reactions
    for i = 1:numel(branching_complexes)
        for j = 1:numel(branching_complexes{i})
            for k = j+1:numel(branching_complexes{i})
                
                % The list will have unique pairings: if (1, 2) is recorded, (2, 1) will no longer be noted
                branching_reaction(end+1, :) = [branching_complexes{i}(j), branching_complexes{i}(k)];
            end
        end
    end
    
    
    
    %
    % Form kinetic order matrix F
    %
    
    % Initialize matrix F
    F = [ ];
    
    % Go through each reaction
    for i = 1:numel(model.reaction)
        
        % Case 1: The reaction is NOT reversible
        if model.reaction(i).reversible == 0
            
            % Add a row of zeros
            F(end+1, :) = zeros(1, m);
            
            % Fill out the kinetic order of all the species in the reactant
            for j = 1:numel(model.reaction(i).kinetic.reactant1)
                F(end, find(strcmp(model.reaction(i).reactant(j).species, model.species))) = model.reaction(i).kinetic.reactant1(j);
            end
        
        % Case 2: The reaction is reversible
        else
            
            % Add a row of zeros
            F(end+1, :) = zeros(1, m);
            
            % Fill out the kinetic order of all the species in the reactant in the first direction
            for j = 1:numel(model.reaction(i).kinetic.reactant1)
                F(end, find(strcmp(model.reaction(i).reactant(j).species, model.species))) = model.reaction(i).kinetic.reactant1(j);
            end
            
            % Add a row of zeros
            F(end+1, :) = zeros(1, m);
            
            % Fill out the kinetic order of all the species in the reactant in the other direction
            for j = 1:numel(model.reaction(i).kinetic.reactant2)
                F(end, find(strcmp(model.reaction(i).product(j).species, model.species))) = model.reaction(i).kinetic.reactant2(j);
            end
        end
    end
    
    
    
    %
    % Check if the kinetic orders of each pair of branching reactions are identical
    %
    
    % Initialize list to track each pair
    F_identical = [ ];
    
    % Go through each pair
    for i = 1:size(branching_reaction, 1)
        
        % 1 means the pair has the same kinetic orders, 0 otherwise
        F_identical(i) = isequal(F(branching_reaction(i, 1), :), F(branching_reaction(i, 2), :));
    end
    
    % Case 1: There is at least 1 pair with different kinetic orders
    if ismember(0, F_identical)
        
        % The PLK system does NOT have reactant-determined kinetics (RDK)
        is_RDK = 0;
    
    % Case 2: Each pair have the same kinetic order
    else
        
        % The PLK system has RDK
        is_RDK = 1;
    end