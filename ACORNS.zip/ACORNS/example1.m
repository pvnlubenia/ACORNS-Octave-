# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 1                                                                #
#                                                                             #
#                                                                             #
# This is Running Example 2 in Fontanil, et al (2020): Early STAT signaling   #
#    network coupled with the receptor complex formation upon interferon      #
#    induction                                                                #
#                                                                             #
# RESULT: The network has absolute concentration robustness in 4 species:     #
#            R1, R1I, R2, and R2I.                                            #
#                                                                             #
# Reference: Fontanil, L.L., Mendoza, E.R., and Fortun, N.T. (2020). A        #
#    computational approach to concentration robustness in power law kinetic  #
#    systems of Shinar-Feinberg type. arXiv:2011.02866 [physics.chem-ph].     #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Running Example 2';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', 'R1I<->R1', 'reactant', struct('species', {'R1I'}, 'stoichiometry', {1}), 'product', struct('species', {'R1'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(2) = struct('id', 'R2<->R2I', 'reactant', struct('species', {'R2'}, 'stoichiometry', {1}), 'product', struct('species', {'R2I'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(3) = struct('id', 'R2+R1I<->R*', 'reactant', struct('species', {'R2', 'R1I'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [1]));
model.reaction(4) = struct('id', 'R*<->R1+R2I', 'reactant', struct('species', {'R*'}, 'stoichiometry', {1}), 'product', struct('species', {'R1', 'R2I'}, 'stoichiometry', {1, 1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1, 1]));
model.reaction(5) = struct('id', 'R*+S2<->R*S2*', 'reactant', struct('species', {'R*', 'S2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*S2*'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [1]));
model.reaction(6) = struct('id', 'R*S2*->R*+S2*', 'reactant', struct('species', {'R*S2*'}, 'stoichiometry', {1}), 'product', struct('species', {'R*', 'S2*'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(7) = struct('id', 'R*S2*+S1->R*S2*S1*', 'reactant', struct('species', {'R*S2*', 'S1'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*S2*S1*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(8) = struct('id', 'R*S2*S1*->R*S2*+S1*', 'reactant', struct('species', {'R*S2*S1*'}, 'stoichiometry', {1}), 'product', struct('species', {'R*S2*', 'S1*'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(9) = struct('id', '2S1*->S1*S1*', 'reactant', struct('species', {'S1*'}, 'stoichiometry', {2}), 'product', struct('species', {'S1*S1*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [2], 'reactant2', [ ]));
model.reaction(10) = struct('id', 'S1*S1*->2S1', 'reactant', struct('species', {'S1*S1*'}, 'stoichiometry', {1}), 'product', struct('species', {'S1'}, 'stoichiometry', {2}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(11) = struct('id', 'S1*+S2*->S1*S2*', 'reactant', struct('species', {'S1*', 'S2*'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'S1*S2*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(12) = struct('id', 'S1*S2*->S1+S2', 'reactant', struct('species', {'S1*S2*'}, 'stoichiometry', {1}), 'product', struct('species', {'S1', 'S2'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);