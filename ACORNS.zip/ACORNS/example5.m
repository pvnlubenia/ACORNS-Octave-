# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 5                                                                #
#                                                                             #
#                                                                             #
# This is Example 2.32 in Meshkat, et al (2021): A network with only one      #
#    species                                                                  #
#                                                                             #
# RESULT: The network does not have a Shinar-Feinberg pair. Hence, the        #
#            algorithm cannot be used.                                        #
#         Note: The network has no absolute concentration robustness in       #
#            species A.                                                       #
#                                                                             #
# Reference: Meshkat, N., Shiu, A., and Torres, A. (2021). Absolute           #
#    concentration robustness in networks with low-dimensional stoichiometric #
#    subspace. Vietnam Journal of Mathematics. doi:10.1007/s10013-021-00524-5.#
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2.32';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', 'A->0', 'reactant', struct('species', {'A'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(2) = struct('id', 'A<->2A', 'reactant', struct('species', {'A'}, 'stoichiometry', {1}), 'product', struct('species', {'A'}, 'stoichiometry', {2}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(3) = struct('id', '3A->4A', 'reactant', struct('species', {'A'}, 'stoichiometry', {3}), 'product', struct('species', {'A'}, 'stoichiometry', {4}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);