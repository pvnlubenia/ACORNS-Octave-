# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 8                                                                #
#                                                                             #
#                                                                             #
# This is Example 4 in Fortun and Mendoza (2020): A network with power law    #
#    kinetics                                                                 #
#                                                                             #
# RESULT: The network has no independent decomposition with a Shinar-Feinberg #
#            pair. Hence, the algorithm was not able to identify absolute     #
#            concentration robustness in any species.                         #
#         Note: The network has absolute concentration robustness in species  #
#            X1 and X3.                                                       #
#                                                                             #
# Reference: Fortun, N.T. and Mendoza, E.R. (2020). Absolute concentration    #
#    robustness in power law kinetic systems. MATCH Communications in         #
#    Mathematical and in Computer Chemistry, 85(-), 669-691.                  #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', 'X1->X1+X3', 'reactant', struct('species', {'X1'}, 'stoichiometry', {1}), 'product', struct('species', {'X1', 'X3'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(2) = struct('id', 'X1+X3->X1+X2', 'reactant', struct('species', {'X1', 'X3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [0.5, 0.5], 'reactant2', [ ]));
model.reaction(3) = struct('id', 'X1+X2->X1', 'reactant', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X1'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [-1, 0.5], 'reactant2', [ ]));
model.reaction(4) = struct('id', 'X1->X2+X3', 'reactant', struct('species', {'X1'}, 'stoichiometry', {1}), 'product', struct('species', {'X2', 'X3'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [0.5], 'reactant2', [ ]));
model.reaction(5) = struct('id', 'X2+X3->X1+X2', 'reactant', struct('species', {'X2', 'X3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);