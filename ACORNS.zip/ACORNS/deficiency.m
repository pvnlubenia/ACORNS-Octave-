# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    deficiency                                                               #
#                                                                             #
#                                                                             #
# OUTPUT: Creates a network out of a list of reactions from another network,  #
#            then returns the deficiency of the newly-formed chemical         #
#            reaction network (CRN).                                          #
#         The output variables model_N1 and delta1 allow the user to view     #
#            the following, respectively:                                     #
#               - New network formed                                          #
#               - Deficiency of the new network                               #
# INPUTS:                                                                     #
#         - model: a structure, representing the CRN, with the following      #
#              fields (the kinetics of the network is not needed):            #
#              - id: name of the model                                        #
#              - species: a list of all species in the network; this is left  #
#                   blank since incorporated into the function is a step      #
#                   which compiles all species used in the model              #
#              - reaction: a list of all reactions in the network, each with  #
#                   the following subfields:                                  #
#                      - id: a string representing the reaction               #
#                      - reactant: has the following further subfields:       #
#                           - species: a list of strings representing the     #
#                                species in the reactant complex              #
#                           - stoichiometry: a list of numbers representing   #
#                                the stoichiometric coefficient of each       #
#                                species in the reactant complex (listed in   #
#                                the same order of the species)               #
#                      - product: has the following further subfields:        #
#                           - species: a list of strings representing the     #
#                                species in the product complex               #
#                           - stoichiometry: a list of numbers representing   #
#                                the stoichiometric coefficient of each       #
#                                species in the product complex (listed in    #
#                                the same order of the species)               #
#                      - reversible: has the value true or false indicating   #
#                           if the reaction is reversible or not, resp.       #
#                      - kinetic: has the following further subfields:        #
#                           - reactant1: a list of numbers representing the   #
#                                kinetic order of each species in the         #
#                                reactant complex in the left to right        #
#                                direction (listed in the same order of the   #
#                                species)                                     #
#                           - reactant2: a list of numbers representing the   #
#                                kinetic order of each species in the         #
#                                reactant complex in the right to left        #
#                                direction (listed in the same order of the   #
#                                species)                                     #
#         - span_B1: list of reaction numbers of 'model' that will be used to #
#              form model_N1                                                  #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 29 October 2021                                                    #
# Last Modified: 30 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function [model_N1, delta1] = deficiency(model, span_B1)
    
    %
    % STEP 1: Create new model model_N1 using the reaction numbers listed in span_B1
    %
    
    % Name the new model
    model_N1.id = 'span_B1';
    
    % Prepare the list of species
    model_N1.species = { };
    
    % Create a vector of model.reaction numbers for the total number of reactions
    reac_num = [ ];
    for i = 1:numel(model.reaction)
        if model.reaction(i).reversible == 0
            reac_num(end+1) = i;
        else
            reac_num(end+1) = i;
            reac_num(end+1) = i;
        end
    end
    
    % Get all model reaction numbers corresponding to the reactions in span_B1
    reac = unique(reac_num(span_B1));
    
    % Put these reaction numbers in model_N1
    for i = 1:numel(reac)
        model_N1.reaction(i) = model.reaction(reac(i));
    end
    
    
    
    %
    % STEP 2: Add to model_N1.species all species indicated in the reactions of model_N1
    %
    
    % Get all species from reactants
    for i = 1:numel(model_N1.reaction)
        for j = 1:numel(model_N1.reaction(i).reactant)
            model_N1.species{end+1} = model_N1.reaction(i).reactant(j).species;
        end
    end
    
    % Get species from products
    for i = 1:numel(model_N1.reaction)
        for j = 1:numel(model_N1.reaction(i).product)
            model_N1.species{end+1} = model_N1.reaction(i).product(j).species;
        end
    end
    
    % Get only unique species
    model_N1.species = unique(model_N1.species);
    
    
    
    %
    % STEP 3: Form stoichiometric matrix N
    %
    
    % Count the number of species
    m = numel(model_N1.species);
    
    % Initialize the matrix of reactant complexes
    reactant_complex = [ ];
    
    % Initialize the matrix of product complexes
    product_complex = [ ];
    
    % Initialize the stoichiometric matrix
    N = [ ];
    
    % For each reaction in the model
    for i = 1:numel(model_N1.reaction)
        
        % Initialize the vector for the reaction's reactant complex
        reactant_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the reactant complex
        for j = 1:numel(model_N1.reaction(i).reactant)
            reactant_complex(find(strcmp(model_N1.reaction(i).reactant(j).species, model_N1.species), 1), end) = model_N1.reaction(i).reactant(j).stoichiometry;
        end
        
        % Initialize the vector for the reaction's product complex
        product_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the product complex
        for j = 1:numel(model_N1.reaction(i).product)
            product_complex(find(strcmp(model_N1.reaction(i).product(j).species, model_N1.species), 1), end) = model_N1.reaction(i).product(j).stoichiometry;
        end
        
        % Create a vector for the stoichiometric matrix: Difference between the two previous vectors
        N(:, end+1) = product_complex(:, end) - reactant_complex(:, end);
        
        % If the reaction is reversible
        if model_N1.reaction(i).reversible
            
            % Insert a new vector for the reactant complex: make it same as the product complex
            reactant_complex(:, end+1) = product_complex(:, end);
            
            % Insert a new vector for the product complex: make it the same as the reactant complex
            product_complex(:, end+1) = reactant_complex(:, end-1);
            
            % Insert a new vector in the stoichiometric matrix: make it the additive inverse of the vector formed earlier
            N(:, end+1) = -N(:, end);
        end
    end
    
    % Count the total number of reactions
    r = size(N, 2);
    
    
    
    %
    % STEP 4: Determine the number of [unique] complexes
    %
    
    % Get just the unique complexes
    % ind2(i) is the index in Y of the reactant complex in reaction i
    % ind(i+r) is the index in Y of the product complex in reaction i     
    [Y, ind, ind2] = unique([reactant_complex, product_complex]', 'rows');
    
    % Construct the matrix of complexes
    Y = Y';
    
    % Count the number of complexes
    n = size(Y, 2);
    
    
    
    %
    % STEP 5: Create an undirected graph
    %
    
    % Initialize an undirected graph g
    g = init_graph();

    % Go through each column of Y (a complex)
    for i = 1:n
        
        % For the zero complex
        if numel(find(Y(:, i))) == 0
            complex = '0';
        
        % Otherwise
        else
            
            % Check which species appear in the complex
            for j = 1:numel(find(Y(:, i)))
                
                % For the first species
                if j == 1
                    
                    % Don't show the stoichiometry if it's 1
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [model.species{find(Y(:, i))(j)}];
                    
                    % Otherwise, include it
                    else
                        complex = [num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                
                % We need the + sign for succeeding species
                else
                    if Y(:, i)(find(Y(:, i))(j)) == 1
                        complex = [complex, '+', model.species{find(Y(:, i))(j)}];
                    else
                        complex = [complex, '+', num2str(Y(:, i)(find(Y(:, i))(j))), model.species{find(Y(:, i))(j)}];
                    end
                end
            end 
        end
        
        % Add this complex in the list of vertices of g
        g = add_vertex(g, complex);
    end
    
    % Add edges to g: Ci -> Cj forms an edge
    % ~ suppresses the original output
    for i = 1:r
        g = add_edge(g, g.vertices{[~, loc] = ismember(reactant_complex(:, i)', Y', 'rows')}, g.vertices{[~, loc] = ismember(product_complex(:, i)', Y', 'rows')});
    end
    
    
    
    %
    % STEP 6: Determine the number of linkage classes
    %
    
    % Initialize the vector which will indicate in which linkage class number a vertex (i.e., complex) belongs to
    linkage_class = zeros(numel(g.vertices), 1);
    
    % Initialize the linkage class number tracker
    linkage_class_num = 0;
    
    % Go to each vertex
    for i = 1:numel(g.vertices)
        
        % Pay attention only to a vertex which has no linkage class number yet
        if linkage_class(i) == 0
            
            % This vertex goes to the next linkage class number
            linkage_class_num += 1;
            
            % Assign the linkage class number to the vertex
            linkage_class(i) = linkage_class_num;
            
            % Take note of the vertex that needs to be checked for edges
            to_check = [i];
            
            % Continue assigning a linkage class number to vertices that get into the check list
            while ~isempty(to_check)
                
                % Get the vertex in the check list
                v1 = to_check(end);
                
                % Remove the vertex from the check list (since we now know which vertex to focus on)
                to_check(end) = [ ];
                
                % Check to which vertices the vertex is connected to
                for j = 1:numel(g.edges{v1})
                    
                    % Take note of the vertex it is connected to
                    v2 = g.edges{v1}(j).vertex;
                    
                    % Pay attention to this vertex if it has no linkage class number yet
                    if linkage_class(v2) == 0
                        
                        % Assign this vertex with the same linkage class number as the vertex it is connected to
                        linkage_class(v2) = linkage_class_num;
                        
                        % Add this vertex to our check list: in the next round, we'll check to which other vertices it is connected to
                        to_check(end+1) = v2;
                    end
                end
            end
        end
    end
    
    % Count the number of linkage classes
    l = max(linkage_class);
    
    
    
    %
    % STEP 7: Determine the rank of the network
    %
    
    % Get the rank of the reaction network
    % S = Im N
    % dim S = dim (Im N) = rank(N)
    % Note: We talk of "dimension of a linear transformation" and "rank of a matrix"
    s = rank(N);
    
    
    
    %
    % STEP 8: Compute the deficiency
    %
    
    % Compute the deficiency of the reaction network
    delta1 = n - l - s;