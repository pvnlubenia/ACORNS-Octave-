# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 7                                                                #
#                                                                             #
#                                                                             #
# This is Example 2.38 in Meshkat, et al (2021): A network with two species   #
#                                                                             #
# RESULT: The network has no nontrivial independent decomposition and its     #
#            deficiency is greater than 1. Hence, the algorithm was not able  #
#            to identify absolute concentration robustness in any species.    #
#         Note: The network has absolute concentration robustness in species  #
#            A.                                                               #
#                                                                             #
# Reference: Meshkat, N., Shiu, A., and Torres, A. (2021). Absolute           #
#    concentration robustness in networks with low-dimensional stoichiometric #
#    subspace. Vietnam Journal of Mathematics. doi:10.1007/s10013-021-00524-5.#
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2.38';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', 'B->A', 'reactant', struct('species', {'B'}, 'stoichiometry', {1}), 'product', struct('species', {'A'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(2) = struct('id', 'A+B->2B', 'reactant', struct('species', {'A', 'B'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'B'}, 'stoichiometry', {2}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(3) = struct('id', '2A+B->A+2B', 'reactant', struct('species', {'A', 'B'}, 'stoichiometry', {2, 1}), 'product', struct('species', {'A', 'B'}, 'stoichiometry', {1, 2}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);