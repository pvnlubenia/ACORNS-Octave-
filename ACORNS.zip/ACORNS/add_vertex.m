# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    add_vertex                                                               #
#                                                                             #
#                                                                             #
# OUTPUT: Adds a vertex to an undirected graph. This is indicated in the      #
#            'vertices' field of the structure representing the graph.        #
# INPUTS:                                                                     #
#         - g: a structure with fields 'vertices' and 'edges'                 #
#         - v: a string representing the vertex                               #
#                                                                             #
# Created: 18 July 2021                                                       #
# Last Modified: 21 July 2021                                                 #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function g = add_vertex(g, v)
    
    % Determine the index of 'v', if it already exists, in the 'vertices' field
    location = find(strcmp(v, g.vertices));
    
    % Case 1: 'location' is empty
    if isempty(location)
        
        % Add vertex 'v' in the list of vertices in 'g'
        g.vertices{end+1} = v;
        
        % Get the vertex number of the added vertex
        vertex_num = find(strcmp(v, g.vertices));
        
        % Initialize the place in 'g.edges' where the edges connecting v to other vertices will be indicated
        g.edges{vertex_num} = [ ];
    
    % Case 2: 'location' is not empty
    else
        disp(['Vertex ' v ' is already in the graph.']);
    end