# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 2                                                                #
#                                                                             #
#                                                                             #
# This is an Illustration in Eloundou-Mbebi, et al (2016): A network with 6   #
#    components                                                               #
#                                                                             #
# RESULT: The network has absolute concentration robustness in 1 species:     #
#            C.                                                               #
#                                                                             #
# Reference: Eloundou-Mbebi, J.M., Küken, A., Omranian, N., Kleesen, S.,      #
#    Neigenfind, J., Basler, G., and Nikoloski, Z. (2016). A network property #
#    necessary for concentration robustness. Nature Communications, 7(13255), # 
#    1-7. doi:10.1038/ncomms13255.                                            #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Illustration';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', '2A<->B', 'reactant', struct('species', {'A'}, 'stoichiometry', {2}), 'product', struct('species', {'B'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(2) = struct('id', 'B->C', 'reactant', struct('species', {'B'}, 'stoichiometry', {1}), 'product', struct('species', {'C'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(3) = struct('id', 'B+C<->D', 'reactant', struct('species', {'B', 'C'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'D'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [1]));
model.reaction(4) = struct('id', 'D->2B', 'reactant', struct('species', {'D'}, 'stoichiometry', {1}), 'product', struct('species', {'B'}, 'stoichiometry', {2}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(5) = struct('id', '2B->A+E', 'reactant', struct('species', {'B'}, 'stoichiometry', {2}), 'product', struct('species', {'A', 'E'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(6) = struct('id', 'A+E->F', 'reactant', struct('species', {'A', 'E'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'F'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(7) = struct('id', '2B<->F', 'reactant', struct('species', {'B'}, 'stoichiometry', {2}), 'product', struct('species', {'F'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);