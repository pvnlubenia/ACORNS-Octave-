# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    Example 3                                                                #
#                                                                             #
#                                                                             #
# This is an example in Kuwahara, et al (2017): A simple two-species          #
#    mass-action reaction system                                              #
#                                                                             #
# RESULT: The network has absolute concentration robustness in 1 species:     #
#            A.                                                               #
#                                                                             #
# Reference: Kuwahara, H., Umarov, R., Almasri, I., and Gao, X. (2017). ACRE: #
#    Absolute concentration robustness exploration in module-based            #
#    combinatorial networks. Synthetic Biology, 2(1), 1-6. doi:10.1093/synbio/#
#    ysk01.                                                                   #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example';
model.species = { }; % do not fill out; will be filled automatically by 'acr'
model.reaction(1) = struct('id', 'A+B->2B', 'reactant', struct('species', {'A', 'B'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'B'}, 'stoichiometry', {2}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(2) = struct('id', 'B->A', 'reactant', struct('species', {'B'}, 'stoichiometry', {1}), 'product', struct('species', {'A'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);