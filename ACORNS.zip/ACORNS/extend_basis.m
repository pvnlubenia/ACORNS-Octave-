# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    extend_basis                                                             #
#                                                                             #
#                                                                             #
# OUTPUT: Basis for the reaction vectors of a chemical reaction network (CRN) #
#            separated into 2 sets:                                           #
#               - B1 containing the Shinar-Feinberg pair of reactions (or one #
#                    of the two reactions, if the pair is linearly dependent) #
#                    that needed to be extended to a basis for the reaction   #
#                    vectors                                                  #
#               - B2 containing the basis vectors added to B1                 #
# INPUTS:                                                                     #
#         - SF_pair1: reaction number of the first reaction in a Shinar-      #
#              Feinberg pair                                                  #
#         - SF_pair2: reaction number of the second reaction in a Shinar-     #
#              Feinberg pair                                                  #
#         - R: matrix of reaction vectors of the CRN                          #
#         - basis: basis for R                                                #
#         - basis_reaction_num: reaction numbers of the reaction vectors that #
#              form the basis for R                                           #
#                                                                             #
# Created: 25 July 2021                                                       #
# Last Modified: 30 October 2021                                              #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function [B1, B2] = extend_basis(SF_pair1, SF_pair2, R, basis, basis_reaction_num)
    
    % Note: A vector v is a linear combination of vectors in a matrix A if the rank of the matrix [A, v] (v is appended to A) is the same as the rank of A
    
    % Initialize the extended basis
    basis_SF = [ ];
    
    % Case 1: The Shinar-Feinberg pair is NOT linearly independent, i.e., each is a linear combo of the other
    if rank([R(SF_pair1, :)', R(SF_pair2, :)']) == rank(R(SF_pair1, :)');
        
        % Use the first reaction vector of the Shinar-Feinberg pair to start the formation of the basis
        basis_SF(end+1, :) = R(SF_pair1, :);
        
        % This forms B1
        B1 = [SF_pair1];
    
    % Case 2: The Shinar-Feinberg pair is linearly independent
    else
        
        % Use the reaction vectors to start the formation of the basis
        basis_SF(end+1, :) = R(SF_pair1, :);
        basis_SF(end+1, :) = R(SF_pair2, :);
        
        % These form B1
        B1 = [SF_pair1, SF_pair2];
    end
    
    % Initialize list of reaction vectors added to extend basis_SF to a basis for R
    added_reaction = [ ];
    
    % Keep on going through each vector in 'basis' until there are s [= rank(N)] elements in basis_SF
    while size(basis_SF, 1) < size(basis, 1)
        
        % Go through each vector in 'basis'
        for i = 1:size(basis, 1)
            
            % If the reaction vector is NOT a linear combination of basis_SF
            if rank([basis_SF', basis(i, :)']) ~= rank(basis_SF')
                
                % Add this vector to basis_SF
                basis_SF(end+1, :) = R(basis_reaction_num(i), :);
                
                % Take note which reaction vectors from 'basis' are added to basis_SF
                added_reaction(end+1) = i;
                
                % Stop forming basis_SF when its size reaches the rank s of the network
                % Note: basis_SF will also have a rank s since it is composed of linearly independent vectors that span R
                if size(basis_SF, 1) == size(basis, 1)
                    break
                end
            end
        end
    end    
    
    % Get the actual reaction number of the added basis vectors
    added_reactions = basis_reaction_num(added_reaction);
    
    % Form the second set of the separated basis vectors
    B2 = basis_reaction_num(added_reaction);